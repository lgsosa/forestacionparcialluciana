"""
Archivo integrador generado automaticamente
Directorio: C:\Users\Luci\OneDrive\Escritorio\Parcial Diseño\python_forestacion\entidades
Fecha: 2025-10-22 10:52:25
Total de archivos integrados: 1
"""

# ================================================================================
# ARCHIVO 1/1: __init__.py
# Ruta: C:\Users\Luci\OneDrive\Escritorio\Parcial Diseño\python_forestacion\entidades\__init__.py
# ================================================================================

﻿


