"""
Archivo integrador generado automaticamente
Directorio: C:\Users\Luci\OneDrive\Escritorio\Parcial Diseño\python_forestacion\entidades\personal
Fecha: 2025-10-22 10:52:25
Total de archivos integrados: 2
"""

# ================================================================================
# ARCHIVO 1/2: __init__.py
# Ruta: C:\Users\Luci\OneDrive\Escritorio\Parcial Diseño\python_forestacion\entidades\personal\__init__.py
# ================================================================================

﻿


# ================================================================================
# ARCHIVO 2/2: operario.py
# Ruta: C:\Users\Luci\OneDrive\Escritorio\Parcial Diseño\python_forestacion\entidades\personal\operario.py
# ================================================================================

﻿class Operario:
    def __init__(self, nombre: str):
        self.nombre = nombre


