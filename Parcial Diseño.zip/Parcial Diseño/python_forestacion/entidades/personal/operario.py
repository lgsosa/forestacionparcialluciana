﻿class Operario:
    def __init__(self, nombre: str):
        self.nombre = nombre
