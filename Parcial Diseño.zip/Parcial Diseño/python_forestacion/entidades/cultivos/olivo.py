﻿from .cultivo import Cultivo
class Olivo(Cultivo):
    def tipo(self) -> str: return "Olivo"
