﻿from .cultivo import Cultivo
class Zanahoria(Cultivo):
    def tipo(self) -> str: return "Zanahoria"
