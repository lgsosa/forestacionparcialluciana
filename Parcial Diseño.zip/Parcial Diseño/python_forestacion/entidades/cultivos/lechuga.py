﻿from .cultivo import Cultivo
class Lechuga(Cultivo):
    def tipo(self) -> str: return "Lechuga"
