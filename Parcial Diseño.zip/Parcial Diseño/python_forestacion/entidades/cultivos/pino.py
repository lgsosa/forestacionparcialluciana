﻿from .cultivo import Cultivo
class Pino(Cultivo):
    def tipo(self) -> str: return "Pino"
