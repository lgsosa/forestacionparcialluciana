﻿class Terreno:
    def __init__(self, nombre: str, superficie_m2: float):
        self.nombre = nombre
        self.superficie_m2 = superficie_m2
