"""
Archivo integrador generado automaticamente
Directorio: C:\Users\Luci\OneDrive\Escritorio\Parcial Diseño\python_forestacion
Fecha: 2025-10-22 10:52:25
Total de archivos integrados: 2
"""

# ================================================================================
# ARCHIVO 1/2: __init__.py
# Ruta: C:\Users\Luci\OneDrive\Escritorio\Parcial Diseño\python_forestacion\__init__.py
# ================================================================================

﻿


# ================================================================================
# ARCHIVO 2/2: constantes.py
# Ruta: C:\Users\Luci\OneDrive\Escritorio\Parcial Diseño\python_forestacion\constantes.py
# ================================================================================

﻿TEMP_RIEGO_MIN = 8
TEMP_RIEGO_MAX = 15
HUMEDAD_UMBRAL = 50
AGUA_MINIMA = 10


