﻿from .forestacion_exception import ForestacionException
class MensajesException(ForestacionException):
    pass
