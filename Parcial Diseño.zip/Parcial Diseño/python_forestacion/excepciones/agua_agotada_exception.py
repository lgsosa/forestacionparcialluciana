﻿from .forestacion_exception import ForestacionException
class AguaAgotadaException(ForestacionException):
    pass
