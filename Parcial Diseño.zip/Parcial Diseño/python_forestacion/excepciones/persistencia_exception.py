﻿from .forestacion_exception import ForestacionException
class PersistenciaException(ForestacionException):
    pass
