﻿from .forestacion_exception import ForestacionException
class SuperficieInsuficienteException(ForestacionException):
    pass
