﻿class ForestacionException(Exception):
    """Excepcion base del dominio."""
    pass
